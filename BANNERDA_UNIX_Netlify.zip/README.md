# BANNERDA UNIX — Netlify deployment

## Files
- `index.html` — complete static website.

## Run locally
Open `index.html` in a modern browser. No build step or dependencies are required.

## Deploy to Netlify
1. Extract the ZIP file.
2. In Netlify, choose **Add new site** → **Deploy manually** (or drag and drop).
3. Upload the extracted folder containing `index.html`.
4. Netlify will publish the static site; no build command or publish directory configuration is needed.

## Passcode
The requested passcode is `BANXMARLO`.

**Security note:** this is a client-side passcode gate for a static website. The passcode is present in the HTML/JavaScript and can be discovered by someone inspecting the source. It hides the interface from casual visitors but is not secure authentication. For real access control, use server-side authentication or a Netlify-supported identity/access-control solution.

## Execution behavior
The EXECUTE sequence validates that both fields are filled and then animates a progress indicator from 1% to 100%. It is visual only: it does not contact WhatsApp, transmit a report, or perform a DNS/network operation.
